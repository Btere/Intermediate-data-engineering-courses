import json
import requests
import logging

logging.basicConfig(level=logging.INFO)


API_KEY = "AIzaSyDvx2Gg54jU4V81wV6Aovq5QGVTgxK8F9c"
BASE_URL = "https://www.googleapis.com/youtube/v3"

def get_100_financial_videos(query="stock market analysis"):
    # --- STEP 1: GATHER 100 VIDEO IDs USING PAGINATION ---
    search_url = f"{BASE_URL}/search"
    video_ids = []
    next_page_token = None
    
    # We need 2 pages because maxResults per page is 50
    for _ in range(2):
        params = {
            'part': 'snippet',
            'q': query,
            'type': 'video',
            'maxResults': 50,
            'pageToken': next_page_token,
            'key': API_KEY
        }
        response = requests.get(search_url, params=params)
        if response.status_code != 200: break
        
        data = response.json()
        video_ids.extend([item['id']['videoId'] for item in data.get('items', [])])
        next_page_token = data.get('nextPageToken')
        if not next_page_token: break

    # --- STEP 2: GET FULL DETAILS IN BATCHES OF 50 ---
    final_dataset = []
    video_url = f"{BASE_URL}/videos"
    
    # Process in chunks of 50 (API limit for videos.list)
    for i in range(0, len(video_ids), 50):
        batch = video_ids[i:i+50]
        params = {
            'part': 'snippet,statistics,contentDetails',
            'id': ','.join(batch),
            'key': API_KEY
        }
        res = requests.get(video_url, params=params)
        if res.status_code != 200: continue
        
        items = res.json().get('items', [])
        for item in items:
            final_dataset.append({
                "video_title": item['snippet']['title'],
                "channel_name": item['snippet']['channelTitle'],
                "video_id": item['id'],
                "published_at": item['snippet']['publishedAt'],
                "duration": item['contentDetails']['duration'],
                "view_count": int(item['statistics'].get('viewCount', 0)),
                "like_count": int(item['statistics'].get('likeCount', 0)),
                "comment_count": int(item['statistics'].get('commentCount', 0))
            })

    # Save final results
    with open("updated_financial_data_100.json", "w") as file:
        json.dump(final_dataset, file, indent=4)
    
    print(f"Extraction Complete: {len(final_dataset)} videos saved.")
    return final_dataset

if __name__ == "__main__":
    get_100_financial_videos()
