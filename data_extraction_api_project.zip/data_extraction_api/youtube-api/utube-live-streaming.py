import requests
import time
import json

API_KEY = "AIzaSyDvx2Gg54jU4V81wV6Aovq5QGVTgxK8F9c"
BASE_URL = "https://www.googleapis.com/youtube/v3"

def get_live_videos(query="stock market"):
    search_url = f"{BASE_URL}/search"

    seen_video_ids = set()

    while True:
        params = {
            "part": "snippet",
            "q": query,
            "type": "video",
            "eventType": "live",
            "maxResults": 50,
            "key": API_KEY
        }

        response = requests.get(search_url, params=params)

        if response.status_code != 200:
            print("API error:", response.text)
            time.sleep(10)
            continue

        data = response.json()
        items = data.get("items", [])

        for item in items:
            video_id = item["id"]["videoId"]

            # avoid duplicates (important for streaming)
            if video_id in seen_video_ids:
                continue

            seen_video_ids.add(video_id)

            live_event = {
                "video_id": video_id,
                "title": item["snippet"]["title"],
                "channel": item["snippet"]["channelTitle"],
                "published_at": item["snippet"]["publishedAt"],
                "live_status": item["snippet"]["liveBroadcastContent"]
            }

            print("LIVE EVENT:", live_event)

            # optional: write to file (stream-like storage)
            with open("live_stream.json", "a") as f:
                f.write(json.dumps(live_event) + "\n")

        # polling interval (simulates streaming)
        time.sleep(30)


if __name__ == "__main__":
    get_live_videos()