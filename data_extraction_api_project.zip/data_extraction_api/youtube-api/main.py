from utube_extraction import get_100_financial_videos
from utube_transformation import run_elt_pipeline
from utube-loading_to_s3 import run_upload_pipeline
from config import QUERY

def run_pipeline():

    # STEP 1: extract
    get_100_financial_videos(query=QUERY)

    # STEP 2: transform
    run_elt_pipeline()

    # STEP 3: load to S3
    run_upload_pipeline()


if __name__ == "__main__":
    run_pipeline()