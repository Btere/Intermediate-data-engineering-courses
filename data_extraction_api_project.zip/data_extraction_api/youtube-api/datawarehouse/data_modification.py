import logging

logger = logging.getLogger(__name__)
table = "yt_api"

def insert_rows(cur, conn, schema,row):
    try:
        if schema == "staging":
            video_id = "video_id"
            
            cur.execute(
                f""" INSERT INTO {schema}.{table}("Vi)"""
            )
            
def update_rows(cur, conn, schema, row):
    try:
        if schema == "staging":
            video_id = "video_id"
            upload_date = "publishedAt"
              