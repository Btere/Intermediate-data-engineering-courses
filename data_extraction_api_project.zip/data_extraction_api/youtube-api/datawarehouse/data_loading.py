import json
from datime import date
import logging

logger = logging.getLogger(__name__)


def load_path():
    file_path = f""
    try:
        logger.info(f"Processing file: YT_data()")
        with open(file_path, "r", encoding="utf-8") as raw_data:
            data = json.load(raw_data)
            return data
    except FileNotFoundError:
        logger.error(f"File not found:{file_path}")
        raise
    except json.JSONDecodeError:
            logger.error(f"Invalid JSON in file: {file_path}")
            
#insert, updates and delete           
        