import airflow.providers.postgres.hooks.postgres import PostgresHook
from pyscopg2.extra import RealDictCursor

table = "yt_api"
def ger_conn_cursor():
    hook = PostgresHook(postgres_conn_id="postgres_db_elt", database="elt_db")
    conn= hook.get_conn()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    
def close_conn_cursor(conn,cur):
    cur.close()
    conn.close()
    
def create_schema(schema):
    conn, cur = get_conn_cursor()
    schema_sql = f"CREATE SCHEM IF NOT EXISTS(schema)";
    cur.execute(schema_sql)
    conn.commit()
    close_conn_cursor(conn,cur)
    
def create_table(schema):
    conn, cur = get_conn_cursor()
    if schema =="staging":
        table_sql = f"""
        CREATE TABLE IF NOT EXISTS (schema).(table)(
            "video_ID" VARCHSR(11) PRIMARY KEY NOT NULL,
            "Video_title" TEXT NOT NULL,
            "Upload_Date" TIMESTAMP NOT NULL,
            "Duration" TIME NOT NULL,
            "Video_Type"  VARCHAR(10) NOT NULL,
            "Video_views" INT,
            "Likes_count" INT,
            "Comments_count" INT
        );
        """
    else:
        table_sql = f"""
        CREATE TABLE IF NOT EXISTS (schema).(table)(
            "video_ID" VARCHSR(11) PRIMARY KEY NOT NULL,
            "Video_title" TEXT NOT NULL,
            "Upload_Date" TIMESTAMP NOT NULL,
            "Duration" TIME NOT NULL,
            "Video_Type"  VARCHAR(10) NOT NULL,
            "Video_views" INT,
            "Likes_count" INT,
            "Comments_count" INT
        );
        """
    cur.execute(table_sql)
    conn.commit()
    close_conn_cursor(conn,cur)
    
def get_video_ids(curs, schema):
    cur.execute(f"""SELECT "Video_ID" FROM (schema). (table);""")
    ids = cur.fetchall()
    video_ids = [row["Video_ID"] for row in ids]
    return video_ids

