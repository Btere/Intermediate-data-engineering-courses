import pandas as pd
import numpy as np
from pathlib import Path
from datetime import datetime, timezone
from scipy import stats
import isodate
import json

# ----------------------------
# CONFIG
# ----------------------------

FINANCIAL_DATASET_PATH = Path("/Users/btereomotere/Downloads/Small Object dataset/data_extraction_api/youtube-api/financial_data_100.json")

# ----------------------------
# LOAD + BASIC PARSING
# ----------------------------

def parse_and_convert(data_path: Path) -> pd.DataFrame:
    df = pd.read_json(data_path)

    # duration → seconds
    df["duration_seconds"] = df["duration"].apply(
        lambda x: isodate.parse_duration(x).total_seconds()
    )

    # consistent UTC datetime
    df["published_at"] = pd.to_datetime(df["published_at"], utc=True)

    # time features
    df["publish_date"] = df["published_at"].dt.date
    df["publish_year"] = df["published_at"].dt.year
    df["publish_month"] = df["published_at"].dt.month
    df["publish_day"] = df["published_at"].dt.day
    df["publish_weekday"] = df["published_at"].dt.weekday
    df["publish_hour"] = df["published_at"].dt.hour
    df["publish_quarter"] = df["published_at"].dt.quarter
    df["publish_dayofyear"] = df["published_at"].dt.dayofyear
    df["publish_weekofyear"] = df["published_at"].dt.isocalendar().week

    return df


# ----------------------------
# ENGAGEMENT METRICS
# ----------------------------

def add_engagement_metrics(df: pd.DataFrame) -> pd.DataFrame:
    now = datetime.now(timezone.utc)

    df["engagement_rate"] = (
        (df["like_count"] + df["comment_count"]) / df["view_count"].replace(0, 1)
    ) * 100

    df["like_rate"] = (df["like_count"] / df["view_count"].replace(0, 1)) * 100
    df["comment_rate"] = (df["comment_count"] / df["view_count"].replace(0, 1)) * 100

    df["views_per_minute"] = df["view_count"] / (df["duration_seconds"] / 60).replace(0, 1)

    # FIXED: consistent timezone-aware subtraction
    df["days_since_published"] = (now - df["published_at"]).dt.days

    df["avg_daily_views"] = df["view_count"] / df["days_since_published"].replace(0, 1)

    return df


# ----------------------------
# TEXT FEATURES
# ----------------------------

def transform_text_features(df: pd.DataFrame) -> pd.DataFrame:
    financial_keywords = [
        "stock", "market", "invest", "trading", "crypto",
        "bitcoin", "earnings", "dividend", "portfolio", "etf"
    ]

    df["title_length"] = df["video_title"].str.len()
    df["title_word_count"] = df["video_title"].str.split().str.len()

    df["financial_keyword_count"] = df["video_title"].str.lower().apply(
        lambda x: sum(1 for kw in financial_keywords if kw in x)
    )

    df["has_numbers"] = df["video_title"].str.contains(r"\d", regex=True)

    df["caps_word_count"] = df["video_title"].apply(
        lambda x: sum(1 for w in x.split() if w.isupper() and len(w) > 1)
    )

    df["exclamation_count"] = df["video_title"].str.count("!")

    df["title_clean"] = df["video_title"].str.lower().str.replace(
        r"[^\w\s]", "", regex=True
    )

    return df


# ----------------------------
# CATEGORIZATION
# ----------------------------

def categorize_videos(df: pd.DataFrame) -> pd.DataFrame:
    df["duration_category"] = pd.cut(
        df["duration_seconds"],
        bins=[0, 60, 300, 600, 1200, 3600, float("inf")],
        labels=["<1min", "1-5min", "5-10min", "10-20min", "20-60min", ">1hour"]
    )

    df["popularity_tier"] = pd.cut(
        df["view_count"],
        bins=[0, 1000, 10000, 100000, 1000000, float("inf")],
        labels=["low", "moderate", "popular", "viral", "mega-viral"]
    )

    df["engagement_score"] = (
        df["engagement_rate"].rank(pct=True) * 0.5 +
        df["like_rate"].rank(pct=True) * 0.3 +
        df["comment_rate"].rank(pct=True) * 0.2
    )

    df["engagement_quality"] = pd.qcut(
        df["engagement_score"],
        q=4,
        labels=["low", "medium", "high", "excellent"]
    )

    return df


# ----------------------------
# OUTLIERS + NORMALIZATION
# ----------------------------

def handle_outliers_and_normalize(df: pd.DataFrame) -> pd.DataFrame:
    df["view_count_zscore"] = stats.zscore(df["view_count"])
    df["is_view_outlier"] = df["view_count_zscore"].abs() > 3

    for col in ["view_count", "like_count", "comment_count"]:
        min_val = df[col].min()
        max_val = df[col].max()
        df[f"{col}_normalized"] = (df[col] - min_val) / (max_val - min_val)

    df["view_count_log"] = np.log1p(df["view_count"])

    return df


# ----------------------------
# TIME FEATURES
# ----------------------------

def time_based_transforms(df: pd.DataFrame) -> pd.DataFrame:
    df["is_weekend"] = df["published_at"].dt.dayofweek >= 5
    df["is_recent"] = df["days_since_published"] <= 30

    df = df.sort_values(["channel_name", "published_at"])
    df["channel_cumulative_views"] = df.groupby("channel_name")["view_count"].cumsum()

    return df


# ----------------------------
# AGGREGATIONS
# ----------------------------

def aggregate_by_channel(df: pd.DataFrame) -> pd.DataFrame:
    channel_df = df.groupby("channel_name").agg(
        video_count=("video_id", "count"),
        total_views=("view_count", "sum"),
        avg_views=("view_count", "mean"),
        median_views=("view_count", "median"),
        total_likes=("like_count", "sum"),
        avg_engagement_rate=("engagement_rate", "mean"),
        avg_duration_sec=("duration_seconds", "mean"),
        latest_video=("published_at", "max"),
        earliest_video=("published_at", "min")
    ).reset_index()

    channel_df["date_range_days"] = (
        channel_df["latest_video"] - channel_df["earliest_video"]
    ).dt.days.replace(0, 1)

    channel_df["videos_per_month"] = (
        channel_df["video_count"] / (channel_df["date_range_days"] / 30)
    )

    return channel_df


# ----------------------------
# PIPELINE
# ----------------------------

def run_elt_pipeline(input_file: Path = FINANCIAL_DATASET_PATH):

    df = parse_and_convert(input_file)
    df = add_engagement_metrics(df)
    df = transform_text_features(df)
    df = categorize_videos(df)
    df = handle_outliers_and_normalize(df)
    df = time_based_transforms(df)

    channel_df = aggregate_by_channel(df)

    # CSV outputs
    df.to_csv("transformed_videos.csv", index=False)
    channel_df.to_csv("channel_aggregates.csv", index=False)

    # Parquet outputs (recommended for analytics systems)
    df.to_parquet("transformed_videos.parquet", index=False)
    channel_df.to_parquet("channel_aggregates.parquet", index=False)

    print(f"Saved {len(df)} transformed rows")
    print(f"Saved {len(channel_df)} channel aggregates")

    return df, channel_df


# ----------------------------
# ENTRY POINT
# ----------------------------

if __name__ == "__main__":
    run_elt_pipeline()