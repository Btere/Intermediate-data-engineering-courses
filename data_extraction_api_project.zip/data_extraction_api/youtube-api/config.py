from pathlib import Path
from dotenv import load_dotenv
import os

# Load environment variables
load_dotenv()

# ------------------------
# PATHS (all pathlib)
# ------------------------
BASE_DIR = Path(__file__).resolve().parent

DATA_DIR = BASE_DIR / "data"
RAW_DIR = DATA_DIR / "raw"
PROCESSED_DIR = DATA_DIR / "processed"

# ------------------------
# API CONFIG
# ------------------------
YOUTUBE_API_KEY = os.getenv("YOUTUBE_API_KEY")
BASE_URL = "https://www.googleapis.com/youtube/v3"

# ------------------------
# AWS CONFIG
# ------------------------
S3_BUCKET = os.getenv("S3_BUCKET")

# ------------------------
# PIPELINE CONFIG
# ------------------------
QUERY = "stock market analysis"
MAX_VIDEOS = 100