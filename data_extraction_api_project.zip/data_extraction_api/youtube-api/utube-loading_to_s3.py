import boto3
import logging
from pathlib import Path
from botocore.exceptions import ClientError

# ----------------------------
# CONFIG
# ----------------------------

s3 = boto3.client("s3")
logging.basicConfig(level=logging.INFO)

BUCKET = "utube-dataset"

FILES_TO_UPLOAD = [
    # transformed dataset
    {
        "local_path": "/Users/btereomotere/Downloads/Small Object dataset/data_extraction_api/youtube-api/dataset/transformed/transformed_videos.csv",
        "s3_prefix": "transformed_dataset/"
    },
    {
        "local_path": "/Users/btereomotere/Downloads/Small Object dataset/data_extraction_api/youtube-api/dataset/transformed/transformed_videos.parquet",
        "s3_prefix": "transformed_dataset/"
    },

    # aggregated dataset
    {
        "local_path": "/Users/btereomotere/Downloads/Small Object dataset/data_extraction_api/youtube-api/dataset/transformed/channel_aggregates.csv",
        "s3_prefix": "aggregated_dataset/"
    },
    {
        "local_path": "/Users/btereomotere/Downloads/Small Object dataset/data_extraction_api/youtube-api/dataset/transformed/channel_aggregates.parquet",
        "s3_prefix": "aggregated_dataset/"
    },
]

# ----------------------------
# UPLOAD FUNCTION
# ----------------------------

def upload_to_s3(file_path: str, bucket: str, key: str):
    try:
        s3.upload_file(Filename=file_path, Bucket=bucket, Key=key)
        logging.info(f"Uploaded: {file_path} → s3://{bucket}/{key}")

    except ClientError as e:
        logging.error(f"S3 Client Error: {e}")

    except Exception as e:
        logging.error(f"Unexpected error: {e}")


# ----------------------------
# MAIN PIPELINE
# ----------------------------

def run_upload_pipeline():
    for file in FILES_TO_UPLOAD:
        local_path = Path(file["local_path"])
        prefix = file["s3_prefix"]

        # keep original filename
        filename = local_path.name

        # final S3 key
        s3_key = f"{prefix}{filename}"

        upload_to_s3(str(local_path), BUCKET, s3_key)


if __name__ == "__main__":
    run_upload_pipeline()