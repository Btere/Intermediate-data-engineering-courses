import logging
import json
from pathlib import Path

# ------------------------
# LOGGER
# ------------------------
def get_logger(name: str):
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)

    if not logger.handlers:
        handler = logging.StreamHandler()
        formatter = logging.Formatter(
            "%(asctime)s | %(levelname)s | %(name)s | %(message)s"
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)

    return logger


# ------------------------
# JSON LOADER (pathlib version)
# ------------------------
def load_json(path: Path):
    path = Path(path)
    return json.loads(path.read_text())


# ------------------------
# JSON WRITER (pathlib version)
# ------------------------
def save_json(data, path: Path):
    path = Path(path)
    path.write_text(json.dumps(data, indent=4))