from pathlib import Path
import warnings
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler, MinMaxScaler, LabelEncoder
from sklearn.model_selection import train_test_split
from imblearn.over_sampling import SMOTE
from imblearn.under_sampling import RandomUnderSampler
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix, classification_report
import warnings
warnings.filterwarnings('ignore')
from dataset_overview import read_csv_files, data_overview, data_cleaning


DATASET_PATH = Path("/Users/btereomotere/Downloads/Small Object dataset/fraud-detection/dataset/raw_dataset/credit_card_fraud_10k.csv")


def exploratory_data_analysis():
    """_summary_
    """
    is_fraund_count = read_csv_files['merchant_category'].value_counts()
    plt.figure(figsize=(8,6))
    plt.bar(is_fraund_count.index, is_fraund_count,color='deeppink')
    plt.title('Class Distribution')
    plt.xlabel('Class')
    plt.ylabel('Count')
    plt.show()
    
    
def plot_bar_for_value_counts(train_dataset:pd.DataFrame, column:str) -> None:
    """_summary_

    Args:
        train_dataset (pd.DataFrame): _description_
        column (str): _description_
    """
    is_fraund_count = train_dataset['is_fraud'].value_counts()
    plt.figure(figsize=(8,6))
    plt.bar(is_fraund_count.index, is_fraund_count,color='deeppink')
    plt.title('Class Distribution')
    plt.xlabel('Class')
    plt.ylabel('Count')
    plt.show()



def plot_bar_for_transaction_hour(train_dataset:pd.DataFrame) -> None:
    """_summary_

    Args:
        train_dataset (pd.DataFrame): _description_
    """
    is_fraund_count = train_dataset['transaction_hour'].value_counts().sort_index()
    plt.figure(figsize=(10,6))
    plt.bar(is_fraund_count.index, is_fraund_count,color='deeppink')
    plt.title('Transaction Hour Distribution')
    plt.xlabel('Transaction Hour')
    plt.ylabel('Number of Transactions')
    plt.xticks(rotation=0) # Ensure hours are readable
    plt.grid(axis='y', linestyle='--', alpha=0.7)
    plt.tight_layout() # Adjust layout to prevent labels from being cut off
    plt.show()
    
    
#transaction that happened btw 0-5hrs
def get_transactions_0_to_5(train_dataset:pd.DataFrame) -> int:
    is_fraund_count = train_dataset['transaction_hour'].value_counts().sort_index()
    transactions_0_to_5 = is_fraund_count.loc[0:5].sum()
    print(f"Total transactions between hour 0 and 5: {transactions_0_to_5}")
    return transactions_0_to_5


#transaction that happened btw 0-5hrs
def get_transactions_6_to_12(train_dataset:pd.DataFrame) -> int:
    is_fraund_count = train_dataset['transaction_hour'].value_counts().sort_index()
    transactions_6_to_12 = is_fraund_count.loc[6:12].sum()
    print(f"Total transactions between hour 6 and 12: {transactions_6_to_12}")
    return transactions_6_to_12


#boxplot of the class distribution
def plot_boxplot_for_transaction_amount_by_hour(train_dataset:pd.DataFrame) -> None:
    """_summary_

    Args:
        train_dataset (pd.DataFrame): _description_
    """ 
    plt.figure(figsize=(14, 7))
    sns.boxplot(x='transaction_hour', y='amount', data=train_dataset, palette='viridis')
    plt.title('Distribution of Transaction Amount by Hour')
    plt.xlabel('Transaction Hour')
    plt.ylabel('Transaction Amount')
    plt.grid(axis='y', linestyle='--', alpha=0.7)
    plt.tight_layout()
    plt.show()
    
def plot_histogram_for_transaction_amount(train_dataset:pd.DataFrame) -> None:
    """_summary_

    Args:
        train_dataset (pd.DataFrame): _description_
    """  
    plt.figure(figsize=(10, 6))
    plt.hist(train_dataset['amount'], bins=50, color='skyblue', edgecolor='black')
    plt.title('Distribution of Transaction Amount')
    plt.xlabel('Transaction Amount')
    plt.ylabel('Frequency')
    plt.grid(axis='y', linestyle='--', alpha=0.7)
    plt.tight_layout()
    plt.show()