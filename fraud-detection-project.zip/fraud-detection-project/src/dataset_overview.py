from pathlib import Path
import warnings
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler, MinMaxScaler, LabelEncoder
from sklearn.model_selection import train_test_split
from imblearn.over_sampling import SMOTE
from imblearn.under_sampling import RandomUnderSampler
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix, classification_report
import warnings
warnings.filterwarnings('ignore')

DATASET_PATH = Path("/Users/btereomotere/Downloads/Small Object dataset/fraud-detection/dataset/raw_dataset/credit_card_fraud_10k.csv")
def read_csv_files(dataset_path:Path) -> pd.DataFrame:
    """_summary_

    Args:
        dataset_path (Path): read dataset

    Returns:
        pd.DataFrame: 
    """
    train_dataset = pd.read_csv(dataset_path, index_col=False)
    return train_dataset


#Data overview

def data_overview(train_dataset:pd.DataFrame) -> None:
    """_summary_

    Args:
        train_dataset (pd.DataFrame): _description_
    """
    print("Dataset shape:", train_dataset.shape)
    print("\nDataset info:")
    print(train_dataset["is_fraud"].value_counts())
    print("train_dataset.value_counts()")
    print(train_dataset.isnull().sum())
    print("\nMissing values in each column:")
    train_dataset.isna().sum()
    print(train_dataset.nunique())
    print(train_dataset.describe())
    
    print(train_dataset.isnull().sum())
    
    
def data_cleaning(train_dataset:pd.DataFrame) -> pd.DataFrame:
    """_summary_

    Args:
        train_dataset (pd.DataFrame): _description_

    Returns:
        pd.DataFrame: _description_
    """
    # Check for duplicates
    duplicates = train_dataset.duplicated().sum()
    drop_na = train_dataset.dropna(inplace=True)
    print(f"Number of duplicate rows: {duplicates}")
    
    # Remove duplicates if any
    if duplicates > 0:
        train_dataset = train_dataset.drop_duplicates()
        print(f"Removed {duplicates} duplicate rows.")
    
    return train_dataset




if __name__ =="__main__":
    train_dataset = read_csv_files(DATASET_PATH)
    data_overview(train_dataset)
    train_dataset = data_cleaning(train_dataset)

    print(train_dataset.shape)
    train_dataset.head(20)
