import joblib

# Define filenames for your model and preprocessors
def save_model_and_preprocessors(model, le_merchant_category, standard_scaler, min_max_scaler):
    model_filename = 'logistic_regression_model.joblib'
    le_filename = 'label_encoder_merchant_category.joblib'
    ss_filename = 'standard_scaler.joblib'
    mms_filename = 'min_max_scaler.joblib'

    # Save the trained Logistic Regression model
    joblib.dump(model, model_filename)
    print(f"Trained model saved successfully to {model_filename}")

    # Save the fitted preprocessors
    joblib.dump(le_merchant_category, le_filename)
    print(f"LabelEncoder saved to {le_filename}")
    joblib.dump(standard_scaler, ss_filename)
    print(f"StandardScaler saved to {ss_filename}")
    joblib.dump(min_max_scaler, mms_filename)
    print(f"MinMaxScaler saved to {mms_filename}")