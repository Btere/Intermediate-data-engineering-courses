# Fraud detection probelm
1. what is credit card fraud detection?
2. what is the goal of the problem
3. what are the methodology bank uss to detect CC fraud detection?
4. How does ML solve it?
5. How do we detect credit card fraud from a dataset?
6. What is the dataset about?
7. What do you observe from the dataset before you clean, after EDA?
8. Visualization you applied?
9. what are the feature engineering you they do to 
10.  How do you detect and handle missing data, what kind of inconsistencies do we expereince in fianacial dataset?
11. what are the risk indicator in a dataset that tells if a dataset is fraudlent or not?

## About the dataset
This dataset contains 10,000 credit card transactions designed to support research and experimentation in fraud detection using machine learning. The data realistically simulates both legitimate and fraudulent transactions, while maintaining a naturally imbalanced class distribution, which reflects real-world financial systems.

The dataset is suitable for binary classification tasks, where the objective is to predict whether a transaction is fraudulent (1) or legitimate (0) based on transaction behavior, risk indicators, and cardholder information.


### Objective of the problem

To build and evaluate machine learning models that can identify fraudulent credit card transactions using transaction-level features such as amount, time, location mismatch, device trust, and transaction velocity.

#### Potential Use Cases
Credit card fraud detection systems
Imbalanced classification problems
Feature engineering and risk analysis
Model comparison (Logistic Regression, Random Forest, XGBoost, etc.)


#### Dataset feature

Feature Name	Description
transaction_id	Unique identifier for each transaction
amount	Transaction amount
transaction_hour	Hour of transaction (0–23)
merchant_category	Type of merchant
foreign_transaction	Indicates if transaction is international (0/1)
location_mismatch	Billing vs transaction location mismatch (0/1)
device_trust_score	Trust score of the device (0–100)
velocity_last_24h	Number of transactions in last 24 hours
cardholder_age	Age of the cardholder.


#### why is it reasonable to scale dataset
Scaling a dataset is a crucial preprocessing step in many machine learning workflows for several reasons:

Equal Contribution of Features: Many machine learning algorithms calculate the distance between data points (e.g., K-Nearest Neighbors, Support Vector Machines, K-Means Clustering). If features have different scales, the features with larger values might dominate the distance calculation, making the smaller-scaled features less impactful, even if they are highly predictive. Scaling ensures that all features contribute equally to the distance metrics.

Algorithm Convergence: Optimization algorithms used in many machine learning models (like gradient descent for linear regression, logistic regression, neural networks) converge much faster when features are on a similar scale. Without scaling, the cost function can have a very elongated shape, leading to slow and oscillating convergence.

Preventing Domination by Large Values: Features with a larger range of values might inadvertently receive more weight in the model's learning process. Scaling brings all features to a comparable range, preventing any single feature from dominating solely due to its magnitude.

Regularization Benefits: Some regularization techniques (e.g., L1 and L2 regularization) are sensitive to the scale of features. Scaling helps these techniques work effectively by ensuring that penalties are applied fairly across all features.

##### Common scaling techniques include:

Standardization (Z-score normalization): Transforms data to have a mean of 0 and a standard deviation of 1. It's useful when features have different scales and the algorithm assumes normally distributed data.
Normalization (Min-Max scaling): Scales data to a fixed range, usually 0 to 1. It's beneficial when the data distribution is not Gaussian or when you want to bound the feature values within a specific range.


##### How do we handle data imbalance in finacial dataset?
Class imbalance occurs when one class in a classification problem significantly outweighs the other class. It’s common in many machine learning problems. Examples include fraud detection, anomaly detection, and medical diagnosis.
A model trained on an imbalanced dataset perform poorly on the minority class. At best, this can cause loss to the business in the case of a churn analysis.
The common approach to solve class imbalance is called resampling. This invlove or entails oversampling the  majority class, and undersampling the minority class or a combination of both We have 
1. over sampling which is the most approach we use. It involves increasing the number of instances in the minority class to match the size ofte majority class. This may cause overfitting to minority class, creating synthetic data can increases redundancy, which might result in model memorizing rather than generalizing.
2. random oversampling
3. random undersampling
4. oversampling through SMOTE
5. Undersampling through SMOTE
Oversampling through Tomek Link

When to fix class imbalance


# imbalance dataset can result in overfitting to the majority class or underfitting to the minority class. We are unable to see the true correlation of the dataset.

ccuracy score never helps in imbalanced dataset, common metrics are precision, recall, fi score or confusion matrix.